package utils;

import tileengine.TETile;
import tileengine.Tileset;
import utils.FileUtils;

public class GameFileUtils {
    private static final String SAVE_FILE = "save_data.txt";



    public void saveBoard(TETile[][] tiles) {
        StringBuilder sb = new StringBuilder();
        sb.append(tiles.length).append(" ").append(tiles[0].length).append("\n");

        for (int y = 0; y < tiles[0].length; y++) {
            for (int x = 0; x < tiles.length; x++) {
                sb.append(tileToChar(tiles[x][y])).append(" ");
            }
            sb.append("\n");
        }

        FileUtils.writeFile(SAVE_FILE, sb.toString());
    }

    // Helper method to convert a tile to its character representation.
    private char tileToChar(TETile tile) {
        if (tile == Tileset.FLOOR) {
            return '0';
        } else if (tile == Tileset.WALL) {
            return '1';
        } // ... more else if statements for other tile types.
        return 'x'; // Default case or error case.
    }

    // Loading the game state, adapted for multiple types of tiles.
    public TETile[][] loadBoard(String filename) {
        String fileContent = FileUtils.readFile(filename);
        String[] lines = fileContent.trim().split("\n");

        int width = Integer.parseInt(lines[0].split(" ")[0]);
        int height = Integer.parseInt(lines[0].split(" ")[1]);

        TETile[][] tiles = new TETile[width][height];

        for (int y = 0; y < height; y++) {
            String[] row = lines[y + 1].trim().split(" ");
            for (int x = 0; x < width; x++) {
                tiles[x][y] = charToTile(row[x].charAt(0));
            }
        }

        return tiles;
    }

    // Helper method to convert a character representation to its respective tile.
    private TETile charToTile(char c) {
        switch (c) {
            case '0': return Tileset.FLOOR;
            case '1': return Tileset.WALL;
            // ... more cases for other tile types.
            default: return Tileset.NOTHING;
        }
    }
}
