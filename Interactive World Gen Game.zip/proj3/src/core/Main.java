package core;

import edu.princeton.cs.algs4.StdDraw;
import tileengine.TERenderer;
import tileengine.TETile;
import tileengine.Tileset;
import java.io.IOException;

import java.awt.event.KeyEvent;

public class Main {
    private Player player;
    private TETile[][] world;
    private TERenderer ter;
    private SpriteExtractor spriteExtractor;

    private static final int WIDTH = 80;
    private static final int HEIGHT = 30;

    public Main() {
        // Initialize the game components
        String spriteSheetPath = "/path/to/your/spritesheet.png"; // Use resource loading in a real app
        int spriteSize = 16;
        this.world = new TETile[WIDTH][HEIGHT];
        fillWorldWithNothing();


        this.ter = new TERenderer();
        this.ter.initialize(WIDTH, HEIGHT);
        this.player = new Player(WIDTH / 2, HEIGHT / 2, world);
        try {
            this.spriteExtractor = new SpriteExtractor("C:/Users/kaden/sp24-s1163/proj3/src/TilesRogue/Girl-Mage.png", 16);
        } catch (IOException e) {
            System.out.println("Error loading sprite sheet: " + e.getMessage());
        }
    }

    private void fillWorldWithNothing() {
        for (int x = 0; x < WIDTH; x++) {
            for (int y = 0; y < HEIGHT; y++) {
                world[x][y] = Tileset.NOTHING;
            }
        }
    }

    public void run() {
        while (true) {
            if (StdDraw.isKeyPressed(KeyEvent.VK_W)) player.move(0, 1);
            if (StdDraw.isKeyPressed(KeyEvent.VK_S)) player.move(0, -1);
            if (StdDraw.isKeyPressed(KeyEvent.VK_A)) player.move(-1, 0);
            if (StdDraw.isKeyPressed(KeyEvent.VK_D)) player.move(1, 0);
            ter.renderFrame(world);
            StdDraw.pause(20); // to slow down the loop
        }
    }

    public static void main(String[] args) {
        Main game = new Main();
        game.run();
    }
}