package core;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.awt.image.BufferedImage;

public class SpriteExtractor {


    private BufferedImage spriteSheet;
    private int spriteSize; // Assuming square sprites for simplicity

    public SpriteExtractor(String path, int spriteSize) throws IOException {
        this.spriteSheet = ImageIO.read(new File(path));
        this.spriteSize = spriteSize;
    }

    public BufferedImage getSprite(Player.PlayerState state) {
        int numberOfSpritesPerRow = spriteSheet.getWidth() / spriteSize;
        int row = state.ordinal() / numberOfSpritesPerRow;
        int column = state.ordinal() % numberOfSpritesPerRow;
        return spriteSheet.getSubimage(column * spriteSize, row * spriteSize, spriteSize, spriteSize);
    }
}