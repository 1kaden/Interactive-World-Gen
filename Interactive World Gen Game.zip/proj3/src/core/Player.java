package core;

import tileengine.TETile;
import tileengine.Tileset;

public class Player {
    private int x, y; // Player position
    private PlayerState currentState;
    private TETile[][] world;

    public enum PlayerState {
        MOVING_UP,
        MOVING_DOWN,
        MOVING_LEFT,
        MOVING_RIGHT,
        Deleted, DEAD
    }

    public Player(int x, int y, TETile[][] world) {
        this.x = x;
        this.y = y;
        this.world = world;
        this.world[x][y] = Tileset.AVATAR;
    }



    public void move(int dx, int dy) {
        int newX = x + dx;
        int newY = y + dy;
        updateState(dx, dy);

        if (canMoveTo(newX, newY)) {
            world[x][y] = Tileset.FLOOR;
            x = newX;
            y = newY;
            world[x][y] = Tileset.AVATAR;
        }

    }
    private void updateState(int dx, int dy) {
        if (dx > 0) currentState = PlayerState.MOVING_RIGHT;
        else if (dx < 0) currentState = PlayerState.MOVING_LEFT;
        else if (dy > 0) currentState = PlayerState.MOVING_UP;
        else if (dy < 0) currentState = PlayerState.MOVING_DOWN;
        else if (dy == 310) currentState = PlayerState.Deleted;
        //


        // Add other states as needed
        // change states and change the character sprite use 2d graphic handler
        //
    }

    private boolean canMoveTo(int newX, int newY) {
        // Implement your collision detection logic here
        // For example:
        return newX >= 0 && newX < world.length && newY >= 0 && newY < world[0].length &&
                world[newX][newY] != Tileset.WALL;
    }

}