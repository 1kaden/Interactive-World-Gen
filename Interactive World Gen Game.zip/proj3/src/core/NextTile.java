package core;

import tileengine.TETile;
import tileengine.Tileset;

public class NextTile {

    private Player player;
    private TETile[][] world;

    public TETile[][] nextGeneration(TETile[][] tiles) {
        TETile[][] nextGen = new TETile[x][y];
        fillWithNothingTiles(nextGen);
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                int liveNeighbors = countLiveNeighbors(tiles, x, y);
                if (tiles[x][y] == Tileset.CELL) {
                    // Rule 1 and 3
                    if (liveNeighbors < 2 || liveNeighbors > 3) nextGen[x][y] = Tileset.NOTHING;
                    else nextGen[x][y] = Tileset.CELL; // Rule 2
                } else {
                    // Rule 4
                    if (liveNeighbors == 3) nextGen[x][y] = Tileset.CELL;
                }
            }
        }
        return nextGen;
    }

    public void World() {
        this.world = new TETile[x][y];
        fillWithNothingTiles();
    }

    private void fillWithNothingTiles() {
        for (int x = 0; x < WIDTH; x++) {
            for (int y = 0; y < HEIGHT; y++) {
                world[x][y] = Tileset.NOTHING;
            }

        }
    }
}