package core;

import tileengine.TETile;
import tileengine.Tileset;
import utils.RandomUtils;

import java.util.Random;

public class World {

    private static final int WIDTH = 80;
    private static final int HEIGHT = 30;
    private TETile[][] world;

    public World() {
        this.world = new TETile[WIDTH][HEIGHT];
        fillWithNothingTiles();
    }

    private void fillWithNothingTiles() {
        for (int x = 0; x < WIDTH; x++) {
            for (int y = 0; y < HEIGHT; y++) {
                world[x][y] = Tileset.NOTHING;
            }
        }
    }

    public void generateWorld(long seed) {
        Random rand = new Random(seed);
        // Implement world generation logic here
        // This should include generating rooms, hallways, and ensuring connectivity
    }

    public TETile[][] getWorld() {
        return world;
    }

    // Additional methods for generating rooms, hallways, checking connectivity, etc.
}